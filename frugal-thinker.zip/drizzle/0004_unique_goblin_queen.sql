CREATE TABLE `goals` (
	`id` integer PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`status` text NOT NULL,
	`startDate` text NOT NULL,
	`targetDate` text NOT NULL
);
