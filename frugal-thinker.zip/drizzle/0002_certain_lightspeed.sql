DROP TABLE `burndownRates`;--> statement-breakpoint
ALTER TABLE `payments` DROP COLUMN `debtId`;