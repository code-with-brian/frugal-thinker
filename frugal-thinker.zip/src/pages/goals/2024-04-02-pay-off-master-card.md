---
layout: ../../layouts/GoalPost.astro
title: Pay off Master Card 💳
author: Frugal Thinker
description: "Create First Youtube Video"
pubDate: 2022-08-08
tags: ["goal", "victory","milestone"]
targetDate: "2024-12-31"
status: "Completed"
---