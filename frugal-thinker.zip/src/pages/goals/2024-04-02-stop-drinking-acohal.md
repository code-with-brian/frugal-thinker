---
layout: ../../layouts/GoalPost.astro
title: 1 Year Alcohal Free 🍺
author: Frugal Thinker
description: "This post will show up on its own!"
pubDate: 2022-08-08
tags: ["goal", "victory","milestone"]
targetDate: "2024-12-31"
status: "On-Track"
---