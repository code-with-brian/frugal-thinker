declare module 'cssesc';
declare module 'html-escaper';